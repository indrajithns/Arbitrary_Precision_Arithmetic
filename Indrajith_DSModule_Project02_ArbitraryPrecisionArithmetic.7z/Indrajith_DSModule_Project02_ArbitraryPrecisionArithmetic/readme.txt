Command Line Argument To Execute The Data Structure Programming Project01 For Arbitrary Precision Arithmetic 

Command to run all the .c files: make   
Command to run output file: ./apc

This will give the required output